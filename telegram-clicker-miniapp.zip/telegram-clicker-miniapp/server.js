import express from "express";
import crypto from "node:crypto";
import Database from "better-sqlite3";
import path from "node:path";
import { fileURLToPath } from "node:url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const app = express();
const PORT = process.env.PORT || 3000;
const BOT_TOKEN = process.env.BOT_TOKEN;

if (!BOT_TOKEN) {
  console.error("Set BOT_TOKEN in your hosting provider's environment variables.");
  process.exit(1);
}

app.use(express.json({ limit: "20kb" }));
app.use(express.static(path.join(__dirname, "public")));

const db = new Database(process.env.DB_PATH || path.join(__dirname, "clicker.sqlite"));
db.pragma("journal_mode = WAL");
db.exec(`
  CREATE TABLE IF NOT EXISTS players (
    telegram_id TEXT PRIMARY KEY,
    username TEXT,
    first_name TEXT,
    coins INTEGER NOT NULL DEFAULT 0,
    power INTEGER NOT NULL DEFAULT 1,
    level INTEGER NOT NULL DEFAULT 1,
    last_daily TEXT
  )
`);

function verifyInitData(initData) {
  if (typeof initData !== "string" || !initData) return null;

  const params = new URLSearchParams(initData);
  const hash = params.get("hash");
  if (!hash) return null;
  params.delete("hash");

  const authDate = Number(params.get("auth_date"));
  if (!Number.isFinite(authDate) || Math.abs(Date.now() / 1000 - authDate) > 86400) {
    return null;
  }

  const dataCheckString = [...params.entries()]
    .sort(([a], [b]) => a.localeCompare(b))
    .map(([key, value]) => `${key}=${value}`)
    .join("\n");

  const secretKey = crypto.createHmac("sha256", "WebAppData").update(BOT_TOKEN).digest();
  const calculatedHash = crypto.createHmac("sha256", secretKey).update(dataCheckString).digest("hex");

  const a = Buffer.from(calculatedHash, "hex");
  const b = Buffer.from(hash, "hex");
  if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) return null;

  try {
    const user = JSON.parse(params.get("user") || "null");
    if (!user?.id) return null;
    return user;
  } catch {
    return null;
  }
}

function auth(req, res, next) {
  const user = verifyInitData(req.header("X-Telegram-Init-Data"));
  if (!user) return res.status(401).json({ error: "Open this game from your Telegram bot." });
  req.telegramUser = user;
  next();
}

const getPlayer = db.prepare("SELECT * FROM players WHERE telegram_id = ?");
const createPlayer = db.prepare(`
  INSERT OR IGNORE INTO players (telegram_id, username, first_name)
  VALUES (?, ?, ?)
`);
const updateProfile = db.prepare(`
  UPDATE players SET username = ?, first_name = ? WHERE telegram_id = ?
`);

function ensurePlayer(user) {
  const id = String(user.id);
  createPlayer.run(id, user.username || null, user.first_name || "Игрок");
  updateProfile.run(user.username || null, user.first_name || "Игрок", id);
  return getPlayer.get(id);
}

function publicPlayer(p) {
  return {
    coins: p.coins,
    power: p.power,
    level: p.level,
    upgradeCost: p.level * 100,
    dailyAvailable: p.last_daily !== new Date().toISOString().slice(0, 10)
  };
}

app.get("/api/me", auth, (req, res) => {
  res.json(publicPlayer(ensurePlayer(req.telegramUser)));
});

app.post("/api/tap", auth, (req, res) => {
  const user = req.telegramUser;
  const id = String(user.id);
  ensurePlayer(user);
  const tx = db.transaction(() => {
    const p = getPlayer.get(id);
    db.prepare("UPDATE players SET coins = coins + ? WHERE telegram_id = ?").run(p.power, id);
    return getPlayer.get(id);
  });
  res.json(publicPlayer(tx()));
});

app.post("/api/upgrade", auth, (req, res) => {
  const id = String(req.telegramUser.id);
  ensurePlayer(req.telegramUser);
  const tx = db.transaction(() => {
    const p = getPlayer.get(id);
    const cost = p.level * 100;
    if (p.coins < cost) return { error: "Недостаточно монет", player: publicPlayer(p) };
    db.prepare(`
      UPDATE players
      SET coins = coins - ?, power = power + 1, level = level + 1
      WHERE telegram_id = ?
    `).run(cost, id);
    return { player: publicPlayer(getPlayer.get(id)) };
  });
  const result = tx();
  if (result.error) return res.status(400).json(result);
  res.json(result.player);
});

app.post("/api/daily", auth, (req, res) => {
  const id = String(req.telegramUser.id);
  ensurePlayer(req.telegramUser);
  const today = new Date().toISOString().slice(0, 10);
  const tx = db.transaction(() => {
    const p = getPlayer.get(id);
    if (p.last_daily === today) return { alreadyClaimed: true, player: publicPlayer(p) };
    db.prepare("UPDATE players SET coins = coins + 250, last_daily = ? WHERE telegram_id = ?").run(today, id);
    return { alreadyClaimed: false, player: publicPlayer(getPlayer.get(id)) };
  });
  const result = tx();
  if (result.alreadyClaimed) return res.status(409).json({ error: "Бонус уже получен сегодня", ...result });
  res.json(result.player);
});

app.get("*", (req, res) => res.sendFile(path.join(__dirname, "public", "index.html")));

app.listen(PORT, () => console.log(`Clicker is running on port ${PORT}`));